import { useState, useRef, useEffect } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Copy, Check, ExternalLink, ArrowUp, Mail } from 'lucide-react';
import skills from '../../data/skills.json';
import { profile } from '../data/portfolio';
import { Chapter, Divider, Roll } from './UI';
export default function Contact() {
    const [toast, setToast] = useState<'copied' | 'error' | null>(null);
    const timer = useRef<number | undefined>(undefined);
    useEffect(() => () => window.clearTimeout(timer.current), []);
    const copy = async () => {
        try {
            if (navigator.clipboard && window.isSecureContext)
                await navigator.clipboard.writeText(profile.email);
            else {
                const el = document.createElement('textarea');
                el.value = profile.email;
                el.style.position = 'fixed';
                el.style.opacity = '0';
                document.body.appendChild(el);
                el.select();
                const ok = document.execCommand('copy');
                el.remove();
                if (!ok)
                    throw new Error('Clipboard unavailable');
            }
            setToast('copied');
        }
        catch {
            setToast('error');
        }
        window.clearTimeout(timer.current);
        timer.current = window.setTimeout(() => setToast(null), 2000);
    };
    return <footer id="contact" className="contact-section"><div className="section-shell"><div className="section-title-row"><Chapter number="04" title="SKILLS & CONTACT" subtitle="Nền tảng vững. Sẵn sàng xây dựng."/><span className="mono section-aside">ALWAYS CURIOUS.<br />ALWAYS BUILDING.</span></div><div className="skills-grid">{skills.map((category, i) => <article className="skill-card" key={category.title}><span className="skill-index mono">/ 0{i + 1}</span><h3>{category.title}</h3><ul>{category.items.map(item => <li key={item}>{item}</li>)}</ul></article>)}</div><div className="credentials"><div><span className="eyebrow">EDUCATION / 2023 — 2027</span><h3>Đại học Cần Thơ</h3><p>Kỹ thuật Phần mềm · Sinh viên năm cuối</p><span className="credential-value mono">3.81 <small>/ 4.0 GPA</small></span></div><div><span className="eyebrow">ENGLISH / 01.2026</span><h3>TOEIC Certificate</h3><p>Đọc hiểu tài liệu kỹ thuật & giao tiếp công việc cơ bản</p><span className="credential-value mono">675 <small>/ 990</small></span></div></div></div><div className="marquee" aria-label="Let's build something solid — available for full-stack roles"><div className="marquee-track" aria-hidden="true">{[0, 1, 2, 3].map(i => <span key={i}>LET'S BUILD SOMETHING SOLID <span className="marquee-star">✳</span> AVAILABLE FOR FULL-STACK ROLES <span className="marquee-star">✳</span> </span>)}</div></div><div className="section-shell contact-bottom"><div className="contact-intro"><p className="eyebrow"><span className="status-dot"/> AVAILABLE FOR OPPORTUNITIES</p><h2>Have something<br />in mind? <span>Let's talk.</span></h2><p>Mình đang tìm cơ hội Junior Full-Stack Developer.<br />Sẵn sàng học hỏi, cộng tác và đóng góp cho sản phẩm thực tế.</p></div><div className="contact-actions"><span className="eyebrow">ONE CLICK. WE'RE CONNECTED.</span><button className="email-button" onClick={copy} aria-label={`Sao chép email ${profile.email}`}><span>{profile.email}</span>{toast === 'copied' ? <Check size={22}/> : <Copy size={22}/>}</button><div className="contact-links"><a href={`mailto:${profile.email}`}><Roll>Gửi email</Roll><Mail size={15}/></a><a href={`tel:+84${profile.phone.slice(1)}`}><Roll>{profile.phone}</Roll></a></div><div className="social-links"><a href={profile.github} target="_blank" rel="noopener noreferrer"><Roll>GitHub</Roll><ExternalLink size={16}/></a><a href={profile.linkedin} target="_blank" rel="noopener noreferrer"><Roll>LinkedIn</Roll><ExternalLink size={16}/></a><span className="mono">Cần Thơ, Việt Nam</span></div></div><div className="footer-bottom"><Divider light/><span className="mono">© {new Date().getFullYear()} · CRAFTED WITH INTENT.</span><span className="mono footer-stack">REACT / TYPESCRIPT / A LITTLE CURIOSITY</span><a href="#top"><Roll>BACK TO TOP</Roll><ArrowUp size={15}/></a></div></div><AnimatePresence>{toast && <motion.div role="status" className={`toast ${toast === 'error' ? 'toast-error' : ''}`} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }}>{toast === 'copied' ? <Check size={18}/> : <Mail size={18}/>}<span>{toast === 'copied' ? '[ COPIED TO CLIPBOARD ]' : 'Không thể sao chép. Bạn có thể chọn Gửi email.'}</span></motion.div>}</AnimatePresence></footer>;
}
