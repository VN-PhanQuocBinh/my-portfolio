import { motion } from 'framer-motion';
import type { ReactNode } from 'react';
export function Roll({ children }: {
    children: string;
}) {
    return <span className="roll" aria-label={children}><span aria-hidden="true">{Array.from(children).map((char, i) => <span className="roll-char" key={i} style={{ '--i': i } as React.CSSProperties}><span>{char === ' ' ? '\u00a0' : char}</span><span>{char === ' ' ? '\u00a0' : char}</span></span>)}</span></span>;
}
export function Divider({ light = false }: {
    light?: boolean;
}) {
    return <motion.div className={`divider ${light ? 'divider-light' : ''}`} initial={{ scaleX: 0 }} whileInView={{ scaleX: 1 }} viewport={{ once: true, margin: '0px 0px -20px 0px' }} transition={{ duration: .8, ease: [.16, 1, .3, 1] }}/>;
}
export function Reveal({ children, className = '', delay = 0 }: {
    children: ReactNode;
    className?: string;
    delay?: number;
}) {
    return <motion.div className={className} initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: .1 }} transition={{ duration: .8, delay, ease: [.16, 1, .3, 1] }}>{children}</motion.div>;
}
export function Chapter({ number, title, subtitle }: {
    number: string;
    title: string;
    subtitle: string;
}) {
    return <div className="chapter-heading"><span className="chapter-number">{number}</span><div><p className="eyebrow">{number} // {title}</p><p className="chapter-subtitle">{subtitle}</p></div></div>
     // {title}</p><p className="chapter-subtitle">{subtitle}</p></div></div>;
}
